# TODO - 다음 작업 사항

**마지막 업데이트**: 2025-10-22 11:30
**현재 상태**: GitHub Pages 배포 완료, 이미지 경로 문제 일부 해결 중

---

## 🚨 중요 사항

### 작업 원칙 (CLAUDE.md 참고)
1. **모든 수정 사항은 반드시 사용자 확인 후 진행**
2. **디자인 변경사항은 Figma 기준으로 확인**
3. **불확실한 부분은 질문 먼저, 추측 금지**

### 현재 문제점
- ⚠️ **레이아웃 컴포넌트의 디자인이 임의로 작성됨**
- Figma 디자인을 확인하지 않고 스타일 적용
- 실제 디자인과 다를 가능성 높음

---

## 📋 즉시 해야 할 작업

### 0. 이미지 경로 문제 해결 (긴급) ⚠️

**문제**: GitHub Pages 배포 시 이미지 경로에 base URL(`/tany_front/`)이 자동으로 붙지 않음

**해결 방법**: `getPublicUrl` 헬퍼 함수 사용

**헬퍼 함수 위치**: `src/utils/getPublicUrl.js`
```javascript
export const getPublicUrl = (path) => {
  const base = import.meta.env.BASE_URL || '/'
  const cleanPath = path.startsWith('/') ? path.slice(1) : path
  return `${base}${cleanPath}`
}
```

**사용 방법**:
```jsx
// Before
<img src="/images/logo.png" />

// After
import { getPublicUrl } from '../../utils/getPublicUrl'
<img src={getPublicUrl('/images/logo.png')} />
```

**수정 필요한 파일** (4개):
- [ ] `src/pages/About/History.jsx`
- [ ] `src/pages/About/Location.jsx`
- [ ] `src/pages/References/LEDCases.jsx`
- [ ] `src/pages/References/StandLED.jsx`

**이미 수정 완료**:
- [x] `src/components/features/home/MainBanner.jsx`

**참고**: `/images/` 경로를 찾아서 `getPublicUrl('/images/...')` 로 감싸기

---

### 1. 레이아웃 컴포넌트 디자인 수정 (최우선)

#### Header 디자인 확인 필요
- [ ] Figma에서 Header 디자인 확인
- [ ] 높이 (현재: 80px PC / 60px Mobile)
- [ ] 로고 디자인 (현재: "TANY" 텍스트만)
- [ ] 메뉴 스타일 (폰트 크기, 간격, 색상)
- [ ] 배경색 (현재: 흰색)
- [ ] 테두리/그림자 여부
- [ ] 햄버거 메뉴 디자인 (모바일)

**파일**:
- `src/components/layout/Header.jsx`
- `src/components/layout/Header.module.css`

#### Footer 디자인 확인 필요
- [ ] Figma에서 Footer 디자인 확인
- [ ] 배경색 (현재: #1C1C1C)
- [ ] 레이아웃 구조 (현재: 3컬럼 그리드)
- [ ] 포함할 정보 (회사정보, 연락처, 링크 등)
- [ ] 소셜 링크 아이콘 디자인
- [ ] 저작권 표시 위치와 스타일

**파일**:
- `src/components/layout/Footer.jsx`
- `src/components/layout/Footer.module.css`

#### PageBanner 디자인 확인 필요
- [ ] Figma에서 Banner 디자인 확인
- [ ] 배경색/이미지 (현재: Primary 그라데이션)
- [ ] 높이
- [ ] 텍스트 정렬 (현재: 중앙)
- [ ] 폰트 크기와 굵기
- [ ] 여백/패딩

**파일**:
- `src/components/layout/PageBanner.jsx`
- `src/components/layout/PageBanner.module.css`

#### SubMenuNav 디자인 확인 필요
- [ ] Figma에서 SubMenu 디자인 확인
- [ ] 배경색 (현재: 흰색)
- [ ] 메뉴 스타일 (폰트, 간격, 색상)
- [ ] 활성 메뉴 표시 방법 (현재: 하단 보더)
- [ ] Sticky 여부 확인
- [ ] 모바일에서 스크롤 방식

**파일**:
- `src/components/layout/SubMenuNav.jsx`
- `src/components/layout/SubMenuNav.module.css`

---

## 📋 이후 작업 순서

### 2. 메인 페이지 개발
- [ ] Figma 메인 페이지 디자인 분석
- [ ] 섹션별로 나눠서 확인
- [ ] 히어로 섹션
- [ ] 주요 제품 소개
- [ ] 기타 섹션들
- [ ] 메인 페이지 컴포넌트 개발

### 3. 서브 페이지 개발
- [ ] 기업소개 페이지들
  - 연혁, 기술인증, CI, 오시는 길
- [ ] 제품소개 페이지들
  - LED전광판, 스탠드 전광판, LED 현수막, 사이니지
- [ ] 레퍼런스 페이지들 (게시판 형태)
  - LED 전광판 설치사례, 스탠드 전광판 설치사례
- [ ] 고객지원 페이지들
  - 온라인문의 (폼), 자료실 (게시판)

### 4. 공통 컴포넌트 개발
- [ ] Button 컴포넌트
- [ ] Card 컴포넌트 (ProductCard, CaseStudyCard)
- [ ] Form 컴포넌트 (ContactForm)
- [ ] Gallery 컴포넌트 (GalleryGrid)

---

## 🔧 기술 참고 사항

### 현재 설치된 패키지
```json
{
  "react": "19.2.0",
  "react-dom": "19.2.0",
  "react-router-dom": "7.9.4",
  "vite": "7.1.11",
  "@vitejs/plugin-react": "5.0.4"
}
```

### 개발 서버 & 배포
```bash
npm run dev     # 개발 서버 (http://localhost:3001)
npm run build   # 프로덕션 빌드
npm run preview # 빌드 미리보기
npm run deploy  # GitHub Pages 수동 배포
```

### GitHub Pages 배포
- **저장소**: https://github.com/apple9710/tany_front
- **배포 URL**: https://apple9710.github.io/tany_front/
- **자동 배포**: main 브랜치에 push 시 자동 배포 (.github/workflows/deploy.yml)
- **수동 배포**: `npm run deploy` 실행

### 프로젝트 구조
```
tany/
├── docs/              # 프로젝트 문서
│   ├── CLAUDE.md      # 작업 규칙 ⭐
│   ├── PROJECT_SUMMARY.md
│   ├── WORK_LOG.md
│   └── TODO.md        # 이 파일
├── src/
│   ├── components/
│   │   ├── layout/    # Header, Footer, PageBanner, SubMenuNav
│   │   └── content/   # (아직 비어있음)
│   ├── pages/         # (아직 비어있음)
│   ├── styles/
│   │   ├── variables.css  # 디자인 시스템 (CSS Variables)
│   │   └── reset.css      # CSS Reset
│   ├── assets/
│   ├── App.jsx
│   ├── App.css
│   └── main.jsx
├── index.html
├── vite.config.js
└── package.json
```

### 디자인 시스템 (CSS Variables)

**색상**:
```css
--color-primary: #F26966        /* 메인 브랜드 색상 */
--color-black: #000000
--color-dark-gray-1: #1A1311
--color-dark-gray-2: #1C1C1C
--color-dark-gray-3: #1D1D1D
--color-gray-1: #313131
--color-gray-2: #484848
--color-gray-3: #707070
--color-white: #FFFFFF
```

**폰트**: Pretendard Variable (CDN)
```css
--font-family: 'Pretendard Variable', Pretendard, ...
```

**간격** (개발하며 조정 가능):
```css
--spacing-xs: 4px
--spacing-sm: 8px
--spacing-md: 16px
--spacing-lg: 24px
--spacing-xl: 32px
--spacing-2xl: 48px
--spacing-3xl: 64px
```

---

## 🎨 디자인 작업 프로세스

### Figma 확인 시 체크리스트
1. **레이아웃 구조** - 섹션 나누기, 그리드
2. **색상** - 배경, 텍스트, 포인트 색상
3. **타이포그래피** - 폰트 크기, 굵기, 행간
4. **간격/여백** - 패딩, 마진, 섹션 간격
5. **반응형** - 모바일 디자인 확인
6. **인터랙션** - 호버, 클릭 효과
7. **이미지/아이콘** - 필요한 에셋 확인

### 작업 순서
1. Figma 스크린샷 업로드 또는 구두 설명
2. Claude가 디자인 분석 및 질문
3. 디자인 확정 후 코드 작성
4. 사용자 확인 후 다음 단계

---

## 📝 참고 문서

- **작업 규칙**: `docs/CLAUDE.md` ⭐ 반드시 읽기
- **프로젝트 요약**: `docs/PROJECT_SUMMARY.md`
- **작업 로그**: `docs/WORK_LOG.md`
- **Figma 디자인**: https://www.figma.com/design/YvXphEaVvtFPFkwplhJXgy/tany?node-id=205-1128&t=TvUx2pztN7KB3kn4-1

---

## ⚠️ 주의사항

1. **절대 확인 없이 디자인 진행하지 말 것**
2. 색상은 반드시 CSS Variables 사용
3. 컴포넌트는 CSS Modules 사용 (*.module.css)
4. 모바일 반응형 고려 (min-width: 768px 기준)
5. 접근성 고려 (시맨틱 태그, aria-label 등)

---

**다음 작업 시작 전에 반드시 `docs/CLAUDE.md`를 읽고 시작하세요!**
