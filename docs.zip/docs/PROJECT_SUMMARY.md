# Tany 프로젝트 요약

## 📌 프로젝트 개요

**프로젝트명**: Tany
**시작일**: 2025-10-21
**상태**: 설계 단계

## 🎯 목표

Figma 디자인을 기반으로 Tany 페이지 프론트엔드 구현

## 🔗 참조 링크

- **Figma 디자인**: https://www.figma.com/design/YvXphEaVvtFPFkwplhJXgy/tany?node-id=205-1128&t=TvUx2pztN7KB3kn4-1

## 📋 현재 상태

### 완료된 작업
- [x] 프로젝트 관리 문서 생성 (CLAUDE.md, PROJECT_SUMMARY.md, WORK_LOG.md)
- [x] Figma 디자인 분석 (페이지 구조, 레이아웃, 디자인 시스템)
- [x] 페이지 구조 설계 (라우팅, 레이아웃 패턴)
- [x] 컴포넌트 아키텍처 설계 (Layout/Content 분리)
- [x] 개발 환경 설정 (Vite + React + React Router)
- [x] 레이아웃 컴포넌트 기본 구조 개발 (Header, Footer, PageBanner, SubMenuNav)
- [ ] **레이아웃 컴포넌트 디자인 수정** ⚠️ 최우선
- [ ] 메인 페이지 개발
- [ ] 서브 페이지 개발
- [ ] 컨텐츠 컴포넌트 개발

### ⚠️ 주의사항
- 레이아웃 컴포넌트가 Figma 디자인 확인 없이 임의로 작성됨
- 구조는 유지하되 스타일을 Figma 기준으로 전면 수정 필요
- **다음 작업 시작 전 반드시 `docs/TODO.md` 참고**

## 🛠️ 기술 스택

### 확정된 기술 스택
- **프레임워크**: React 19.2.0
- **빌드 도구**: Vite 7.1.11
- **라우팅**: React Router DOM 7.9.4
- **언어**: JavaScript (ES6+)
- **스타일링**: CSS (CSS Variables + CSS Modules 예정)
- **상태관리**: TBD (필요시 결정)

### 마이그레이션 전략
- **현재**: Vite + React로 개발
- **향후**: Next.js 마이그레이션 가능 (점진적 전환 전략)
  - React 컴포넌트 로직은 그대로 유지 가능
  - 주요 변경사항: 라우팅 구조, 환경변수, 설정파일
  - 난이도: 중간~쉬움 (공식 가이드 제공)

## 📐 페이지 구조

### 사이트 유형
- **멀티 페이지 웹사이트** (LED 전광판 제조/판매 기업 사이트)
- **반응형 디자인**: PC / Mobile

### 네비게이션 구조

#### 헤더 (Header)
- **PC**: 상단 헤더 바 (고정 메뉴)
- **Mobile**: 햄버거 메뉴

#### 주요 페이지/섹션

1. **메인 (Home)**
   - 메인 페이지

2. **기업소개**
   - 연혁
   - 기술인증
   - CI
   - 오시는 길

3. **제품소개**
   - LED 전광판
   - 스탠드 전광판
   - LED 현수막
   - 사이니지

4. **레퍼런스**
   - LED 전광판 설치사례
   - 스탠드 전광판 설치사례

5. **고객지원**
   - 온라인문의
   - 자료실
   - 블로그
   - 인스타그램

### 라우팅 구조 (예상)
```
/ (메인)
/about
  /history (연혁)
  /certification (기술인증)
  /ci (CI)
  /location (오시는 길)
/products
  /led-display (LED전광판)
  /stand-display (스탠드 전광판)
  /led-banner (LED 현수막)
  /signage (사이니지)
/references
  /led-cases (LED 전광판 설치사례)
  /stand-cases (스탠드 전광판 설치사례)
/support
  /inquiry (온라인문의)
  /resources (자료실)
  /blog (블로그)
  /instagram (인스타그램)
```

### 페이지 레이아웃 구조

#### 메인 페이지
- 독립적인 레이아웃 (별도 디자인)

#### 서브 페이지 (공통 레이아웃)
```
┌─────────────────────────┐
│       Header            │ (PC: 헤더바 / Mobile: 햄버거 메뉴)
├─────────────────────────┤
│       Banner            │ (대메뉴 제목 배너)
├─────────────────────────┤
│    SubMenu Nav          │ (소메뉴 목록)
├─────────────────────────┤
│                         │
│       Content           │ (페이지별 콘텐츠)
│                         │
├─────────────────────────┤
│       Footer            │
└─────────────────────────┘
```

### 콘텐츠 타입 분류

#### 1. 랜딩 페이지 형태
- 정적 콘텐츠 중심
- 섹션별 정보 표시
- 예상 페이지:
  - 기업소개 > 연혁, 기술인증, CI, 오시는 길
  - 제품소개 > LED전광판, 스탠드 전광판, LED 현수막, 사이니지
  - 고객지원 > 온라인문의

#### 2. 게시판(갤러리) 형태
- 동적 목록 표시
- 그리드/리스트 뷰
- 예상 페이지:
  - 레퍼런스 > LED 전광판 설치사례, 스탠드 전광판 설치사례
  - 고객지원 > 자료실

#### 3. 외부 링크
- 블로그, 인스타그램 (외부 페이지 연결)

### 주요 컴포넌트 구조

#### Layout Components
- `Header` (PC/Mobile 분기)
- `MobileMenu` (햄버거 메뉴)
- `PageBanner` (대메뉴 제목 배너)
- `SubMenuNav` (소메뉴 네비게이션)
- `Footer`

#### Content Components
- `LandingSection` (랜딩 페이지 섹션)
- `GalleryGrid` (갤러리 그리드)
- `ProductCard` (제품 카드)
- `CaseStudyCard` (설치사례 카드)
- `ContactForm` (온라인문의 폼)
- `Breadcrumb` (경로 표시)

## 🎨 디자인 시스템

### 색상 (Color Palette)

#### Primary Color
- **브랜드 메인**: `#F26966` (코랄/연어색)

#### Grayscale
- **Black**: `#000000`
- **Dark Gray 1**: `#1A1311`
- **Dark Gray 2**: `#1C1C1C`
- **Dark Gray 3**: `#1D1D1D`
- **Gray 1**: `#313131`
- **Gray 2**: `#484848`
- **Gray 3**: `#707070`
- **White**: `#FFFFFF`

#### 사용 방식
- Primary Color: 강조, 버튼, 포인트 요소
- Grayscale: 배경, 텍스트, 푸터 등 전반적 사용

### 타이포그래피 (Typography)

#### 폰트 패밀리
- **메인 폰트**: Pretendard
  - 전체 사이트에 일관되게 사용
  - Variable Font 또는 Static Font 사용 예정

#### 폰트 크기/굵기
- TBD (개발 진행하며 확정)
- 필요 시 제목/본문/캡션별 정의

### 간격/그리드
- TBD (개발 진행하며 확정)
- 섹션 간 여백, 컨테이너 최대 너비 등은 구현 단계에서 정의

## 📝 주요 결정사항

### [2025-10-21 13:00] 프로젝트 시작
- 프로젝트 관리 문서 구조 확립
- Figma MCP 서버 연결 완료
- 체계적인 설계 프로세스 수립

### [2025-10-21 13:30] 기술 스택 결정
- **빌드 도구**: Vite 선택
  - 이유: 빠른 개발 서버, 최신 빌드 도구
- **프레임워크**: React 사용
- **언어**: JavaScript (ES6+) - TypeScript 미사용
  - 이유: 프로젝트 복잡도 및 개발 속도 고려
- **마이그레이션 계획**: Next.js로 향후 전환 가능성 확인
  - 공식 마이그레이션 가이드 존재
  - 컴포넌트 로직 재사용 가능
  - 점진적 전환 전략 채택
- **디자인 분석 방법**: Figma 스크린샷 기반 구두 설명 방식

### [2025-10-21 13:40] 페이지 구조 및 디자인 시스템 확정
- **사이트 유형**: 멀티 페이지 웹사이트 (LED 전광판 제조/판매)
- **페이지 구조**: 5개 메인 카테고리, 약 15개 하위 페이지
- **디자인 시스템 확정**:
  - Primary Color: #F26966 (코랄/연어색)
  - Grayscale: 8단계 그레이스케일 시스템
  - 메인 폰트: Pretendard
- **반응형**: PC / Mobile 대응

### [2025-10-21 13:45] 페이지 레이아웃 구조 상세 분석
- **공통 레이아웃 구조** 확정:
  - Header → Banner (대메뉴) → SubMenu (소메뉴) → Content → Footer
  - 메인 페이지는 독립적인 레이아웃
- **콘텐츠 타입 분류**:
  1. 랜딩 페이지 형태 (정적 콘텐츠)
  2. 게시판/갤러리 형태 (동적 목록)
  3. 외부 링크 (블로그, SNS)
- **컴포넌트 아키텍처**: Layout Components + Content Components 구분

### [2025-10-21 14:30] 개발 환경 초기 설정 완료
- **Vite + React 프로젝트 생성**:
  - React 19.2.0, Vite 7.1.11 설치
  - React Router DOM 7.9.4 설치
- **프로젝트 구조 생성**:
  - src/components/layout, src/components/content 분리
  - src/pages, src/styles, src/assets 구조 생성
- **디자인 시스템 설정**:
  - CSS Variables로 색상, 폰트, 간격 시스템 정의
  - CSS Reset 적용
- **개발 서버 실행**: http://localhost:3001 정상 작동 확인

### [2025-10-21 15:00] 레이아웃 컴포넌트 기본 구조 개발
- **레이아웃 컴포넌트 개발**:
  - Header (PC/Mobile 반응형, 햄버거 메뉴)
  - Footer (3컬럼 그리드)
  - PageBanner (페이지 제목 배너)
  - SubMenuNav (소메뉴 네비게이션)
- **Pretendard 폰트 설정** (CDN)
- **문제점**: Figma 디자인 확인 없이 임의로 스타일 적용
- **조치 필요**: Figma 기준으로 디자인 전면 수정 필요

## 🚀 다음 단계

**⚠️ 중요: 작업 시작 전 `docs/TODO.md` 필독!**

1. **최우선**: 레이아웃 컴포넌트 디자인 수정
   - Figma 디자인 확인하며 Header, Footer, PageBanner, SubMenuNav 스타일 수정
2. 메인 페이지 개발 (Figma 확인 후)
3. 서브 페이지 개발
4. 컨텐츠 컴포넌트 개발

---

**마지막 업데이트**: 2025-10-21 17:30
