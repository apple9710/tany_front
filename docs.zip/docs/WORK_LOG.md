# Tany 작업 로그

## 2025-10-21

### 13:00 - 프로젝트 초기 설정
**작업자**: Claude
**작업 내용**:
- 프로젝트 관리 문서 생성
  - `CLAUDE.md`: 작업 규칙 및 원칙 문서화
  - `PROJECT_SUMMARY.md`: 프로젝트 전체 요약
  - `WORK_LOG.md`: 작업 이력 관리
- Figma MCP 서버 연결 설정 완료
  - 새 API 토큰으로 업데이트
  - 연결 상태 확인 완료 ✓

**다음 작업**:
- Figma 디자인 분석 및 페이지 구조 파악
- 컴포넌트 설계

---

### 13:30 - 기술 스택 결정 및 마이그레이션 전략 수립
**작업자**: Claude
**작업 내용**:
- 기술 스택 확정
  - React 18+ 사용
  - Vite 빌드 도구 선택
  - TypeScript 사용 예정
- Next.js 마이그레이션 가능성 조사
  - 공식 문서 리서치 완료
  - 마이그레이션 가이드 확인: https://nextjs.org/docs/app/guides/migrating/from-vite
  - 자동화 도구 존재 확인 (ViteToNext.AI)

**결정사항**:
- **Vite + React로 시작**: 빠른 개발 환경, 간단한 설정
- **Next.js 마이그레이션 전략**: 점진적 전환 방식
  - 컴포넌트 로직은 재사용 가능
  - 주요 변경사항: 라우팅 구조, 환경변수 prefix, 설정파일
  - 난이도: 중간~쉬움
- **디자인 분석 방법**: 사용자가 Figma 스크린샷 제공 후 구두 설명 방식

**문서 업데이트**:
- `PROJECT_SUMMARY.md`: 기술 스택 및 마이그레이션 전략 섹션 추가
- `WORK_LOG.md`: 현재 작업 내역 기록

**다음 작업**:
- Vite + React 프로젝트 초기 설정
- 디자인 시스템 정의 (색상, 타이포그래피, 스페이싱)
- Figma 디자인 분석 시작 (사용자 스크린샷 대기)

---

### 13:35 - 언어 선택 확정
**작업자**: Claude
**작업 내용**:
- JavaScript (ES6+) 사용 확정
- TypeScript 미사용 결정

**결정사항**:
- **JavaScript 사용 이유**: 프로젝트 복잡도 및 개발 속도 고려
- Vite는 JavaScript 프로젝트도 완벽 지원

**문서 업데이트**:
- `PROJECT_SUMMARY.md`: 언어 섹션 TypeScript → JavaScript 변경
- `WORK_LOG.md`: 언어 선택 결정사항 기록

**다음 작업**:
- Vite + React (JavaScript) 프로젝트 초기 설정

---

### 13:40 - Figma 디자인 분석 완료
**작업자**: Claude
**작업 내용**:
- 전체 페이지 구조 파악
  - 멀티 페이지 웹사이트 (약 15개 페이지)
  - 5개 메인 카테고리: 메인, 기업소개, 제품소개, 레퍼런스, 고객지원
  - PC/Mobile 반응형 디자인
- 디자인 시스템 정의
  - Primary Color: #F26966 (코랄/연어색)
  - Grayscale 8단계 시스템 정리
  - 메인 폰트: Pretendard

**결정사항**:
- **라우팅 구조**: React Router 사용 예정
  - /about, /products, /references, /support 등
  - 중첩 라우팅 활용
- **디자인 토큰**: CSS Variables로 색상 시스템 관리 예정
- **간격/그리드**: 개발하며 점진적으로 정의

**문서 업데이트**:
- `PROJECT_SUMMARY.md`: 페이지 구조, 디자인 시스템 섹션 추가
- `WORK_LOG.md`: 디자인 분석 작업 기록

**다음 작업**:
- Vite + React 프로젝트 초기 설정
- React Router 설정
- 기본 폴더 구조 생성
- 디자인 시스템 (색상 변수) 설정

---

### 13:45 - 페이지 레이아웃 및 컴포넌트 구조 분석
**작업자**: Claude
**작업 내용**:
- 서브 페이지 공통 레이아웃 구조 파악
  - Header → Banner → SubMenu → Content → Footer 구조
  - 메인 페이지는 별도 레이아웃
- 콘텐츠 타입 3가지 분류
  1. 랜딩 페이지 형태 (정적)
  2. 게시판/갤러리 형태 (동적 목록)
  3. 외부 링크
- 컴포넌트 아키텍처 설계
  - Layout Components: Header, PageBanner, SubMenuNav, Footer
  - Content Components: LandingSection, GalleryGrid, ProductCard 등

**결정사항**:
- **Layout 패턴**:
  - 메인 페이지: `MainLayout`
  - 서브 페이지: `SubLayout` (공통 구조 활용)
- **컴포넌트 재사용성**: Layout과 Content 분리로 유지보수성 향상
- **라우팅 전략**: React Router의 Nested Routes 활용

**문서 업데이트**:
- `PROJECT_SUMMARY.md`: 페이지 레이아웃 구조, 컴포넌트 구조 상세화
- `WORK_LOG.md`: 레이아웃 분석 작업 기록

**다음 작업**:
- Vite + React 프로젝트 초기 설정
- 폴더 구조 설계 (components/layout, components/content 분리)
- React Router 설정

---

### 14:30 - Vite + React 프로젝트 초기 설정 완료
**작업자**: Claude
**작업 내용**:
- 개발 환경 설정
  - npm 프로젝트 초기화
  - Vite, React, React Router DOM 설치
  - 프로젝트 구조 생성 (src/components, src/pages, src/styles)
- 디자인 시스템 설정
  - `src/styles/variables.css`: 색상, 폰트, 간격 시스템 CSS Variables 정의
  - `src/styles/reset.css`: CSS Reset 적용
- 기본 파일 생성
  - `vite.config.js`: Vite 설정 (포트 3000)
  - `index.html`: HTML 템플릿
  - `src/main.jsx`: Entry point
  - `src/App.jsx`: 메인 앱 + 기본 라우팅
- 개발 서버 실행 성공: http://localhost:3001

**설치된 패키지**:
- React 19.2.0
- React DOM 19.2.0
- React Router DOM 7.9.4
- Vite 7.1.11
- @vitejs/plugin-react 5.0.4

**프로젝트 구조**:
```
tany/
├── docs/              (문서 파일 이동)
├── src/
│   ├── components/
│   │   ├── layout/
│   │   └── content/
│   ├── pages/
│   ├── styles/
│   │   ├── variables.css
│   │   └── reset.css
│   ├── assets/
│   ├── App.jsx
│   └── main.jsx
├── index.html
├── vite.config.js
└── package.json
```

**문서 업데이트**:
- `PROJECT_SUMMARY.md`: 개발 환경 설정 완료 기록, 기술 스택 버전 업데이트
- `WORK_LOG.md`: 초기 설정 작업 상세 기록

**다음 작업**:
- Pretendard 폰트 설정
- Header, Footer 컴포넌트 개발
- 메인 페이지 레이아웃 개발

---

### 15:00 - 레이아웃 컴포넌트 기본 구조 개발 완료
**작업자**: Claude
**작업 내용**:
- Pretendard 폰트 설정 (CDN - Variable Font)
- 레이아웃 컴포넌트 개발
  - Header: PC/Mobile 반응형, 햄버거 메뉴
  - Footer: 3컬럼 그리드, 회사정보/연락처/링크
  - PageBanner: 페이지 제목 배너 (그라데이션)
  - SubMenuNav: 소메뉴 네비게이션 (Sticky)
- App.jsx 업데이트: 모든 컴포넌트 적용 및 라우팅 설정
- CSS Modules 사용으로 스타일 격리

**생성된 파일**:
```
src/components/layout/
├── Header.jsx & Header.module.css
├── Footer.jsx & Footer.module.css
├── PageBanner.jsx & PageBanner.module.css
└── SubMenuNav.jsx & SubMenuNav.module.css
src/App.css
```

**이슈/문제**:
- ⚠️ **Figma 디자인 확인 없이 임의로 디자인 적용**
- CLAUDE.md의 "확인 후 작업" 원칙 위반
- 실제 디자인과 다를 가능성 높음
- 구조는 유지하되 스타일 전면 수정 필요

**문서 업데이트**:
- `TODO.md`: 다음 작업 사항 및 참고사항 상세 작성
- `WORK_LOG.md`: 레이아웃 컴포넌트 개발 및 문제점 기록

**다음 작업** (TODO.md 참고):
- **최우선**: Figma 디자인 확인 및 레이아웃 컴포넌트 디자인 수정
  - Header, Footer, PageBanner, SubMenuNav 각각 디자인 확인
- 메인 페이지 개발
- 서브 페이지 개발

---

### 11:00 - GitHub Pages 배포 설정 및 이미지 경로 문제 해결
**작업자**: Claude
**작업 내용**:
- GitHub Pages 배포 설정 완료
  - gh-pages 패키지 설치
  - vite.config.js에 base: '/tany_front/' 추가
  - App.jsx에 Router basename="/tany_front" 추가
  - GitHub Actions 워크플로우 생성 (.github/workflows/deploy.yml)
  - package.json에 deploy 스크립트 추가
- 이미지 경로 문제 발견 및 해결
  - 문제: public 폴더의 절대 경로가 base URL 자동 적용 안 됨
  - 해결: getPublicUrl 헬퍼 함수 생성 (src/utils/getPublicUrl.js)
  - MainBanner.jsx에 헬퍼 함수 적용 완료
  - 나머지 4개 파일은 다음 작업 시 수정 필요

**배포 완료**:
- 배포 URL: https://apple9710.github.io/tany_front/
- 수동 배포: `npm run deploy` 명령어로 성공
- 자동 배포: main 브랜치 push 시 GitHub Actions 실행

**이슈/문제**:
- ⚠️ 이미지 경로 문제 부분 해결
  - MainBanner는 수정 완료
  - 나머지 4개 파일 수정 필요 (TODO.md에 기록)
- import 방식 vs getPublicUrl 방식 고민
  - 결론: getPublicUrl 방식 채택 (유지보수 편의성)

**문서 업데이트**:
- `TODO.md`: 이미지 경로 문제 해결 방법 상세 추가
- `WORK_LOG.md`: 배포 작업 기록

**다음 작업**:
- 나머지 4개 파일 이미지 경로 수정
- Figma 디자인 확인 및 레이아웃 컴포넌트 디자인 수정

---

### 작업 템플릿

```markdown
### [시간] - [작업 제목]
**작업자**:
**작업 내용**:
-

**결정사항**:
-

**이슈/문제**:
-

**다음 작업**:
-
```

---

**작업 로그 작성 규칙**:
1. 모든 작업은 시간 순으로 기록
2. 중요한 결정사항은 반드시 이유와 함께 기록
3. 발생한 이슈와 해결 방법 명시
4. 다음 작업 항목 명확히 정리
